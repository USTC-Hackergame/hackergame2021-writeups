/*	SCCS Id: @(#)gnplayer.h	3.4	2000/07/16	*/
/* Copyright (C) 1998 by Erik Andersen <andersee@debian.org> */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef GnomeHackPlayerSelDialog_h
#define GnomeHackPlayerSelDialog_h

int ghack_player_sel_dialog(const char **, const gchar*, const gchar*);

#endif /* GnomeHackPlayerSelDialog_h */
