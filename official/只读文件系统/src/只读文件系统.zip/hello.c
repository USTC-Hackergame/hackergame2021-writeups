#include <stdio.h>

int main() {
    write(1, "hello world\n", 12);
    getchar();
    return 0;
}
