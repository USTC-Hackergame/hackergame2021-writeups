from web3 import Web3
from web3.middleware import geth_poa_middleware
import os
import json
import time

challenge_id = int(input('The challenge you want to play (1 or 2): '))
assert challenge_id == 1 or challenge_id == 2

player_bytecode = bytes.fromhex(input('Player bytecode: '))

print('Launching geth...')
os.system('geth --datadir data --nodiscover --mine --unlock 0x2021fA88b7268C420658e24272253B0D0886579F --password password.txt --verbosity 0 &')
time.sleep(1)
w3 = Web3(Web3.IPCProvider('/data/geth.ipc'))
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
w3.eth.default_account = w3.eth.accounts[0]
w3.geth.personal.unlock_account(w3.eth.default_account, open('password.txt').read().strip())
print('Deploying challenge contract...')
bytecode, abi = json.load(open(f'contract{challenge_id}.json'))
Challenge = w3.eth.contract(abi=abi, bytecode=bytecode)
seed = os.urandom(32)
tx_hash = Challenge.constructor(seed).transact()
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print('Challenge contract address:', tx_receipt.contractAddress)
challenge = w3.eth.contract(address=tx_receipt.contractAddress, abi=abi)
print('Deploying player contract...')
tx_hash = w3.eth.send_transaction({'to': None, 'data': player_bytecode})
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
print('Player contract address:', tx_receipt.contractAddress)
print('Checking flag...')
if challenge.functions.predict_child(tx_receipt.contractAddress).call():
    print(open(f'flag{challenge_id}').read())
else:
    print('Wrong address!')
